"use server";

import { NextResponse } from "next/server";
import { client, db } from "@/app/MongoConfig";
import { ObjectId } from "mongodb";
export async function GET(req) {
     // Code to get all the users data
     const { searchParams } = new URL(req.url);
     const id = searchParams.get("id")
     await client.connect()
     let collection = []
     if (!id) {
          collection = await db.collection('users').find({}).toArray()
     } else {
          collection = await db.collection('users').find({ _id: new ObjectId(id) }).toArray()
     }
     await client.close()
     return NextResponse.json({ data: collection });
}

export async function POST(req) {
     // Code to create or save the users data
     const data = await req.json();
     await client.connect()
     const resp = await db.collection("users").insertOne(data)
     await client.close()
     return NextResponse.json({ message: "User created", data: resp });
}

export async function PUT(req) {
     // Code to update specific user's data
     const { searchParams } = new URL(req.url);
     const id = searchParams.get("id");
     if (!id) {
          return NextResponse.json({ message: "id is required", status: 400 });
     }
     else {

          await client.connect()
          const data = await req.json()
          const resp = await db.collection("users").findOneAndUpdate({ "_id": new ObjectId(id) }, { $set: data })
          await client.close()
          return NextResponse.json({ message: `User with ${id} is Updated`, data: resp });
     }

}

export async function DELETE(req) {
     // Code to delete specific user's data
     const { searchParams } = new URL(req.url);
     const id = searchParams.get("id");
     console.log(id)
     await client.connect()
     const resp = await db.collection("users").findOneAndDelete({ " _id": new ObjectId(id) })
     await client.close()
     return NextResponse.json({ message: `User with is deleted successfully`, data: resp });
}