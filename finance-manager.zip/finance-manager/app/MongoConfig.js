import { MongoClient } from "mongodb";

console.log(process.env.MONGO_DB_URL)
export const client = new MongoClient(process.env.MONGO_DB_URL);
export const db = client.db(process.env.DB_NAME);
