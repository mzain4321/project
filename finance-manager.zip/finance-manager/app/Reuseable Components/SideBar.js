"use client";
import Image from "next/image";
import Link from "next/link";

export default function SideBar({ closeSidebar }) {
  return (
    <div className="w-full h-full border-gray-300">
      <div className="flex gap-4 justify-center items-center mt-5">
        <Image
          src="/FMLogo.jpg"
          width={30}
          height={30}
          alt="FC Logo"
          className="w-[65px] h-[55px] lg:w-[75px] lg:h-[70px] rounded-[100%]"
        />
      </div>
      <div className="mt-7">
        <ul>
          <h1 className="mb-3 text-lg font-serif text-center tracking-wider">Dashboard</h1>
          <div className="border-b-[1px] border-t-[1px] border-gray-300">
            <li
              className="text-center text-sm lg:text-md tracking-widest py-3"
              onClick={closeSidebar} // Close sidebar when clicking
            >
              <Link href="/">Home</Link>
            </li>
            <li
              className="text-center text-sm lg:text-md tracking-widest py-3"
              onClick={closeSidebar} // Close sidebar when clicking
            >
              <Link href="/Pages/Analytics">Analytics</Link>
            </li>
          </div>
        </ul>
      </div>

      <div className="mt-10">
        <ul>
          <h1 className="mb-3 text-lg font-serif text-center tracking-wider">Forms</h1>
          <div className="border-b-[1px] border-t-[1px] border-gray-300">
            <li
              className="text-center text-sm lg:text-md tracking-widest py-3"
              onClick={closeSidebar} // Close sidebar when clicking
            >
              <Link href="/Pages/AccountForm">Add User Account</Link>
            </li>
          </div>
        </ul>
      </div>

    </div>
  );
}
