"use client";
import Image from "next/image";
export default function Cards() {
  return (
    <div>
        <div className='w-full flex flex-col justify-center lg:flex-row lg:justify-around pt-10'>
        <div className='w-full lg:w-[28%] flex justify-center shadow-xl px-6 py-4 rounded-xl border-[1px] border-gray-300'>
          <div className='flex justify-center'>
            <Image src="/PaidIcon.png" width={30} height={30} alt="Paid Icon" className='w-[65px] h-[65px] lg:w-[70px] lg:h-[70px]'></Image>
          </div>
          <div className='text-center mt-1'>
            <h1 className='text-xl font-bold'>Credit</h1>
            <p><b>RS:</b> 200000</p>
            <div className='flex gap-3 mt-4'>
              <Image src="/UpIcon.png" width={30} height={30} alt="Up Icon" className='lg:w-[30px] lg:h-[30px]'></Image>
              <p className='text-green-500 text-md tracking-wide'>10% Increases</p>
            </div>
          </div>
        </div>

        <div className='w-full lg:w-[28%] flex justify-center shadow-xl px-6 py-4 rounded-xl border-[1px] border-gray-300'>
          <div className='flex justify-center'>
            <Image src="/SavingIcon.png" width={30} height={30} alt="Saving Icon" className='w-[65px] h-[65px] lg:w-[70px] lg:h-[70px]'></Image>
          </div>
          <div className='text-center mt-1'>
            <h1 className='text-xl font-bold'>Savings</h1>
            <p><b>RS:</b> 30000</p>
            <div className='flex gap-3 mt-4'>
              <Image src="/UpIcon.png" width={30} height={30} alt="Up Icon" className='lg:w-[30px] lg:h-[30px]'></Image>
              <p className='text-green-600 text-md tracking-wide'>5% Increases</p>
            </div>
          </div>
        </div>

        <div className='w-full lg:w-[28%] flex justify-center shadow-xl px-6 py-4 rounded-xl border-[1px] border-gray-300'>
          <div className='flex justify-center'>
            <Image src="/AtmIcon.png" width={30} height={30} alt="Balance Icon" className='w-[65px] h-[65px] lg:w-[70px] lg:h-[70px]'></Image>
          </div>
          <div className='text-center mt-1'>
            <h1 className='text-xl font-bold'>Balance</h1>
            <p><b>RS:</b> 5200000</p>
            <div className='flex gap-3 mt-4'>
              <Image src="/DownIcon.png" width={30} height={30} alt="Up Icon" className='lg:w-[30px] lg:h-[30px]'></Image>
              <p className='text-red-600 text-md tracking-wide'>10% Decreases</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
