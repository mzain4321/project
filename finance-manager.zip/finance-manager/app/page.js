import Dashboard from "./Pages/Dashboard/page";

export default function Index() {
  return (
    <div>
        <Dashboard/>
    </div>
  );
}
